counter = 0
yes = str(input('Do you have more grades to enter'))
while yes == 'y' or yes == 'Y':
  highest = 0
  lowest = 10
  average = 0
  total = 0
  finalaverage = 0
  overallaverage = 0
  for i in range(5):
    value = float(input('Enter a grade from 0-10'))
    while value < 0 or value > 10:
      value = float(input('Invalid Score, Enter Again'))
    if value > highest:
      highest = value
    if value < lowest:
      lowest = value
    total += value
  print 'lowest',lowest,'highest', highest
  average = (total - highest - lowest)/3
  overallaverage += average 
  print average
  counter = counter + 1
  yes = str(input('Do you have more grades to enter'))
finalaverage = overallaverage/counter
print finalaverage
